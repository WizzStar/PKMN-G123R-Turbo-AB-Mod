# Changelog

Format: [keep a changelog](https://keepachangelog.com/en/1.1.0/).
Version headings match `manifest.json`'s `version`.

## 1.0.0

### Added

- Hold **A** or **B** on dialogue and battle text to auto-advance after a short delay.
- **TURBO A/B**, **TURBO A**, **TURBO B**, **HOLD DELAY**, and **REPEAT SPEED** mod options (same delay and 1–5 speed ladder as G123R Turbo_Scroll Mod).
- Gen 1 / Gen 2: `TextBox` screens and battle text phases. Gen 3: field messages and battle text.
- YES/NO, multichoice, menus, battle command box and move select are never repeated.
- Presses go through `mod.input:tap` (source-safe), with a `pressQueue` fallback.
- Opt-out via `noTurboAB` / `turboAB = false`, screen-id denylist, and `mod.exports`.
