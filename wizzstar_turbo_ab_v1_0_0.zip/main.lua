local DEFAULT_DELAY = 16
local DEFAULT_SPEED = 3
local SPEED_FRAMES = {
  [1] = 14,
  [2] = 12,
  [3] = 10,
  [4] = 8,
  [5] = 6,
}
local DEFAULT_RATE = SPEED_FRAMES[DEFAULT_SPEED]

-- Gen 1 / Gen 2 screen ids and Gen 3 stack layer ids.  Turbo only fires on
-- text, but a minigame that prints text still reads A as gameplay.
local DENY_SCREEN_IDS = {
  -- Gen 1 / Gen 2
  SlotMachine = true,
  SurfingMinigame = true,
  UnownPuzzle = true,
  CardFlip = true,
  NamingScreen = true,
  -- Gen 3
  slot_machine = true,
  rse_slot_machine = true,
  rse_roulette = true,
  rse_roulette_entry = true,
  rse_berry_blender = true,
  rs_berry_blender = true,
  rse_contest = true,
  rse_contest_results = true,
  whiteout_rush = true,
  naming = true,
  pin_entry = true,
  easy_chat = true,
}

-- Battle phases that are message printing, not a command box or move list.
-- Gen 1: src/battle/BattleState.lua; Gen 2: src/ui/gen2/BattleState.lua.
-- YES/NO prompts are their own phases (Gen 2 "ask-*") or a pushed ChoiceBox.
local BATTLE_TEXT_PHASES = {
  intro = true,
  messages = true,
  resolving = true,
}

-- Cached runtime state (zero per-frame table lookups)
local cachedEnabled = true
local cachedTurboA = true
local cachedTurboB = true
local cachedDelay = DEFAULT_DELAY
local cachedSpeed = DEFAULT_SPEED
local cachedRate = DEFAULT_RATE

local function optBool(mod, key)
  local v = mod.options:get(key)
  return v ~= false and v ~= "false"
end

local function optNumber(mod, key, fallback, min, max)
  local v = mod.options and mod.options:get(key)
  local num = tonumber(v) or fallback
  num = math.floor(num + 0.5)
  if num < min then num = min end
  if num > max then num = max end
  return num
end

local function refreshOptions(mod)
  if not mod or not mod.options then return end
  cachedEnabled = optBool(mod, "enabled")
  cachedTurboA = optBool(mod, "turbo_a")
  cachedTurboB = optBool(mod, "turbo_b")
  cachedDelay = optNumber(mod, "initial_delay", DEFAULT_DELAY, 5, 60)
  cachedSpeed = optNumber(mod, "repeat_speed", DEFAULT_SPEED, 1, 5)
  cachedRate = SPEED_FRAMES[cachedSpeed] or DEFAULT_RATE
end

local function optedOut(obj)
  return type(obj) == "table" and (obj.noTurboAB == true or obj.turboAB == false)
end

local function denied(obj)
  if type(obj) ~= "table" then return false end
  if optedOut(obj) then return true end
  local id = obj.screenId or obj.id
  return id ~= nil and DENY_SCREEN_IDS[id] == true
end

-- ------- Gen 3 (FireRed / LeafGreen / Ruby / Sapphire / Emerald)
-- Same module access as Turbo_Scroll: gated on game.generation == 3, through
-- pcall, cached per live Game3.

local gen3Cache = {}
local gen3CacheOwner = nil

local function resetGen3Cache()
  gen3Cache = {}
  gen3CacheOwner = nil
end

local function isGen3(game)
  return type(game) == "table" and game.generation == 3
end

local function gen3Module(game, name)
  if gen3CacheOwner ~= game then
    gen3Cache = {}
    gen3CacheOwner = game
  end
  local m = gen3Cache[name]
  if m == nil then
    local ok, res = pcall(require, name)
    m = (ok and type(res) == "table") and res or false
    gen3Cache[name] = m
  end
  return m or nil
end

local function callBool(t, fname)
  local fn = t and t[fname]
  if type(fn) ~= "function" then return false end
  local ok, res = pcall(fn)
  return ok and res == true
end

local function gen3StackTop(game)
  local Stack = gen3Module(game, "src.ui.game3.stack")
  if not Stack or type(Stack.top) ~= "function" then return nil end
  local ok, layer = pcall(Stack.top)
  if ok and type(layer) == "table" then return layer end
  return nil
end

local function isGen3TextContext(game)
  if game.phase == "arena" or game.phase == "quest_log" then return false end

  -- any open YES/NO or multichoice list reads A as a pick
  local Choice = gen3Module(game, "src.ui.game3.choice")
  if Choice and (Choice.active or callBool(Choice, "isOpen")) then return false end

  local MG = gen3Module(game, "src.core.game3.minigames.common")
  if callBool(MG, "isActive") then return false end

  -- a menu layer (bag, party, PC, shop...) owns A even while it prints a
  -- message, so field text only counts with nothing pushed
  if gen3StackTop(game) then return false end

  local Message = gen3Module(game, "src.ui.game3.message")
  if not Message then return false end

  local Battle = gen3Module(game, "src.core.game3.battle")
  if callBool(Battle, "isActive") then
    local Ui = gen3Module(game, "src.core.game3.battle.ui")
    if not Ui then return false end
    if callBool(Ui, "yesNoPending") or callBool(Ui, "choiceActive") then return false end
    if callBool(Ui, "waitingForCommand") then return false end
    if Ui._mode ~= nil and Ui._mode ~= "none" then return false end
    return callBool(Ui, "dialogPending")
  end

  if not callBool(Message, "isOpen") then return false end
  if callBool(Message, "isHeld") then return false end
  if Message._choice then return false end
  return true
end

-- ------- Gen 1 / Gen 2 (StateStack)

local function getStackTop(game)
  if type(game) ~= "table" then return nil end
  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  if type(stack) == "table" and type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and type(top) == "table" then return top end
  end
  return nil
end

local function isStackTextContext(game)
  local top = getStackTop(game)
  if not top then return false end
  if denied(top) then return false end

  -- src/render/TextBox.lua, shared by Gen 1 and Gen 2.  A box with a choice
  -- ends in YES/NO, where a held A would answer for the player.
  if top.isTextBox then
    return not top.choice
  end

  -- battle text prints inside the battle state; the command box and move
  -- select are other phases of the same state
  if top.isBattle or top.isBattleState then
    return BATTLE_TEXT_PHASES[top.phase] == true
  end

  return false
end

local function isTextContext(game)
  if type(game) ~= "table" then return false end
  if isGen3(game) then return isGen3TextContext(game) end
  return isStackTextContext(game)
end

local function safeTextContext(game)
  local ok, res = pcall(isTextContext, game)
  return ok and res == true
end

local function isDown(input, btn)
  local ok, down = pcall(input.isDown, input, btn)
  return ok and down == true
end

return function(mod)
  mod.options:define({
    {
      key = "enabled",
      type = "toggle",
      label = "TURBO A/B",
      default = true,
    },
    {
      key = "turbo_a",
      type = "toggle",
      label = "TURBO A",
      default = true,
    },
    {
      key = "turbo_b",
      type = "toggle",
      label = "TURBO B",
      default = true,
    },
    {
      key = "initial_delay",
      type = "number",
      label = "HOLD DELAY",
      default = DEFAULT_DELAY,
      min = 5,
      max = 60,
      step = 1,
    },
    {
      key = "repeat_speed",
      type = "choice",
      label = "REPEAT SPEED",
      default = DEFAULT_SPEED,
      choices = {
        { "1", 1 },
        { "2", 2 },
        { "3", 3 },
        { "4", 4 },
        { "5", 5 },
      },
    },
  })

  refreshOptions(mod)

  mod.exports.isTextContext = safeTextContext
  mod.exports.denyScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = true end
  end
  mod.exports.allowScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = nil end
  end
  mod.exports.defaults = {
    initialDelay = DEFAULT_DELAY,
    repeatSpeed = DEFAULT_SPEED,
    repeatRate = DEFAULT_RATE,
    speedFrames = SPEED_FRAMES,
  }

  -- source-safe tap (#807); older engines fall back to the raw press queue
  local function tap(game, btn)
    if mod.input and type(mod.input.tap) == "function" then
      if pcall(mod.input.tap, mod.input, game, btn) then return end
    end
    local queue = game.input.pressQueue
    if type(queue) == "table" then queue[#queue + 1] = btn end
  end

  local holdBtn = nil
  local holdFrames = 0
  local holdDelay = DEFAULT_DELAY
  local holdRate = DEFAULT_RATE

  local function resetHold()
    holdBtn, holdFrames = nil, 0
    holdDelay, holdRate = cachedDelay, cachedRate
  end

  local function heldButton(input)
    local a = cachedTurboA and isDown(input, "a")
    local b = cachedTurboB and isDown(input, "b")
    if a and b then return "ab" end
    if a then return "a" end
    if b then return "b" end
    return nil
  end

  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    -- Fast Exit 1: Master toggle disabled
    if not cachedEnabled then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    local input = type(game) == "table" and game.input
    if type(input) ~= "table" or type(input.isDown) ~= "function" then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    -- Fast Exit 2: No A/B held (skips stack lookups entirely)
    local btn = heldButton(input)
    if not btn then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    -- A+B+SELECT+START is the soft reset combo; leave it untouched
    if isDown(input, "start") or isDown(input, "select") then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    if not safeTextContext(game) then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    if btn ~= holdBtn then
      holdBtn = btn
      holdFrames = 0
      holdDelay = cachedDelay
      holdRate = cachedRate
    end

    holdFrames = holdFrames + 1
    local afterDelay = holdFrames - holdDelay
    if holdFrames > 1 and afterDelay >= 0 and afterDelay % holdRate == 0 then
      if btn == "ab" then
        tap(game, "a")
        tap(game, "b")
      else
        tap(game, btn)
      end
    end

    return nextFn(game, dt)
  end)

  mod.events:on("mod.options_changed", function(ev)
    if not ev or ev.mod ~= mod.id then return end
    refreshOptions(mod)
  end)

  mod.events:on("game.ready", function()
    resetGen3Cache()
    resetHold()
  end)

  mod.events:on("save.loaded", function()
    refreshOptions(mod)
  end)

  mod.log:info("hold A/B on text to auto-advance (cached delay=%d rate=%d)",
    cachedDelay, cachedRate)
end
