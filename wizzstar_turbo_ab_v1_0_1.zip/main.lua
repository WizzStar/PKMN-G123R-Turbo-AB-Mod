local DEFAULT_DELAY = 16
local DEFAULT_SPEED = 3
local SPEED_FRAMES = {
  [1] = 14,
  [2] = 12,
  [3] = 10,
  [4] = 8,
  [5] = 6,
}
local DEFAULT_RATE = SPEED_FRAMES[DEFAULT_SPEED]

-- Gen 1 / Gen 2 screen ids and Gen 3 stack layer ids.  Turbo only fires on
-- text, but a minigame that prints text still reads A as gameplay.
local DENY_SCREEN_IDS = {
  -- Gen 1 / Gen 2
  SlotMachine = true,
  SurfingMinigame = true,
  UnownPuzzle = true,
  CardFlip = true,
  NamingScreen = true,
  -- Gen 3
  slot_machine = true,
  rse_slot_machine = true,
  rse_roulette = true,
  rse_roulette_entry = true,
  rse_berry_blender = true,
  rs_berry_blender = true,
  rse_contest = true,
  rse_contest_results = true,
  whiteout_rush = true,
  naming = true,
  pin_entry = true,
  easy_chat = true,
}

-- Battle phases that are message printing, not a command box or move list.
-- Gen 1: src/battle/BattleState.lua; Gen 2: src/ui/gen2/BattleState.lua.
-- YES/NO prompts are their own phases (Gen 2 "ask-*") or a pushed ChoiceBox.
local BATTLE_TEXT_PHASES = {
  intro = true,
  messages = true,
  resolving = true,
}

-- Boot screens (splash, intro movie, title, main menu).  Every one of them
-- reads a fresh A press as "skip" / "next", so holding A taps through the
-- whole boot into CONTINUE (or NEW GAME with no save, where the first real
-- choice -- name, gender -- stops it).  Holding B only skips the movies and
-- stops at the title screen, since B on a menu means "back".
-- "movie" = skipped by A or B, "menu" = A only.
-- Gen 1: src/core/Game.lua boot; Gen 2: src/core/Game2.lua show*().
local BOOT_SCREEN_IDS = {
  -- Gen 1
  IntroMovie = "movie",
  YellowIntro = "movie",
  TitleState = "menu",
  -- Gen 2
  Gen2CopyrightSplash = "movie",
  Gen2GameFreakPresents = "movie",
  Gen2CrystalSplash = "movie",
  Gen2GoldSilverIntro = "movie",
  Gen2CrystalIntro = "movie",
  Gen2TitleState = "menu",
  Gen2MainMenu = "menu",
}

-- Gen 3 Boot.PHASE values (src/ui/game3/boot.lua, boot_modules.lua).  The
-- title_combo phase (clear save / reset RTC) and mystery gift stay manual.
local GEN3_BOOT_PHASES = {
  copyright = "movie",
  intro = "movie",
  title = "menu",
  title_cry = "menu",
  title_restart = "menu",
  menu = "menu",
}

-- Cached runtime state (zero per-frame table lookups)
local cachedEnabled = true
local cachedBoot = true
local cachedSave = true
local cachedNurse = true
local cachedBattle = false
local cachedTurboA = true
local cachedTurboB = true
local cachedDelay = DEFAULT_DELAY
local cachedSpeed = DEFAULT_SPEED
local cachedRate = DEFAULT_RATE

local function optBool(mod, key)
  local v = mod.options:get(key)
  return v ~= false and v ~= "false"
end

local function optNumber(mod, key, fallback, min, max)
  local v = mod.options and mod.options:get(key)
  local num = tonumber(v) or fallback
  num = math.floor(num + 0.5)
  if num < min then num = min end
  if num > max then num = max end
  return num
end

local function refreshOptions(mod)
  if not mod or not mod.options then return end
  cachedEnabled = optBool(mod, "enabled")
  cachedBoot = optBool(mod, "turbo_boot")
  cachedSave = optBool(mod, "turbo_save")
  cachedNurse = optBool(mod, "turbo_nurse")
  local battle = mod.options:get("turbo_battle")
  cachedBattle = battle == true or battle == "true"
  cachedTurboA = optBool(mod, "turbo_a")
  cachedTurboB = optBool(mod, "turbo_b")
  cachedDelay = optNumber(mod, "initial_delay", DEFAULT_DELAY, 5, 60)
  cachedSpeed = optNumber(mod, "repeat_speed", DEFAULT_SPEED, 1, 5)
  cachedRate = SPEED_FRAMES[cachedSpeed] or DEFAULT_RATE
end

local function optedOut(obj)
  return type(obj) == "table" and (obj.noTurboAB == true or obj.turboAB == false)
end

local function denied(obj)
  if type(obj) ~= "table" then return false end
  if optedOut(obj) then return true end
  local id = obj.screenId or obj.id
  return id ~= nil and DENY_SCREEN_IDS[id] == true
end

-- ------- Gen 3 (FireRed / LeafGreen / Ruby / Sapphire / Emerald)
-- Same module access as Turbo_Scroll: gated on game.generation == 3, through
-- pcall, cached per live Game3.

local gen3Cache = {}
local gen3CacheOwner = nil

local function resetGen3Cache()
  gen3Cache = {}
  gen3CacheOwner = nil
end

local function isGen3(game)
  return type(game) == "table" and game.generation == 3
end

local function gen3Module(game, name)
  if gen3CacheOwner ~= game then
    gen3Cache = {}
    gen3CacheOwner = game
  end
  local m = gen3Cache[name]
  if m == nil then
    local ok, res = pcall(require, name)
    m = (ok and type(res) == "table") and res or false
    gen3Cache[name] = m
  end
  return m or nil
end

local function callBool(t, fname)
  local fn = t and t[fname]
  if type(fn) ~= "function" then return false end
  local ok, res = pcall(fn)
  return ok and res == true
end

local function gen3StackTop(game)
  local Stack = gen3Module(game, "src.ui.game3.stack")
  if not Stack or type(Stack.top) ~= "function" then return nil end
  local ok, layer = pcall(Stack.top)
  if ok and type(layer) == "table" then return layer end
  return nil
end

local function isGen3TextContext(game)
  if game.phase == "arena" or game.phase == "quest_log" then return false end

  -- any open YES/NO or multichoice list reads A as a pick
  local Choice = gen3Module(game, "src.ui.game3.choice")
  if Choice and (Choice.active or callBool(Choice, "isOpen")) then return false end

  local MG = gen3Module(game, "src.core.game3.minigames.common")
  if callBool(MG, "isActive") then return false end

  -- a menu layer (bag, party, PC, shop...) owns A even while it prints a
  -- message, so field text only counts with nothing pushed
  if gen3StackTop(game) then return false end

  local Message = gen3Module(game, "src.ui.game3.message")
  if not Message then return false end

  local Battle = gen3Module(game, "src.core.game3.battle")
  if callBool(Battle, "isActive") then
    local Ui = gen3Module(game, "src.core.game3.battle.ui")
    if not Ui then return false end
    if callBool(Ui, "yesNoPending") or callBool(Ui, "choiceActive") then return false end
    if callBool(Ui, "waitingForCommand") then return false end
    if Ui._mode ~= nil and Ui._mode ~= "none" then return false end
    return callBool(Ui, "dialogPending")
  end

  if not callBool(Message, "isOpen") then return false end
  if callBool(Message, "isHeld") then return false end
  if Message._choice then return false end
  return true
end

-- ------- Gen 1 / Gen 2 (StateStack)

local function getStackTop(game)
  if type(game) ~= "table" then return nil end
  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  if type(stack) == "table" and type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and type(top) == "table" then return top end
  end
  return nil
end

local function isStackTextContext(game)
  local top = getStackTop(game)
  if not top then return false end
  if denied(top) then return false end

  -- src/render/TextBox.lua, shared by Gen 1 and Gen 2.  A box with a choice
  -- ends in YES/NO, where a held A would answer for the player.
  if top.isTextBox then
    return not top.choice
  end

  -- battle text prints inside the battle state; the command box and move
  -- select are other phases of the same state
  if top.isBattle or top.isBattleState then
    return BATTLE_TEXT_PHASES[top.phase] == true
  end

  return false
end

-- ------- Boot screens

local function bootKind(game)
  if isGen3(game) then
    local boot = game.phase == "boot" and game.boot
    if type(boot) ~= "table" or boot.saveError then return nil end
    return GEN3_BOOT_PHASES[boot.phase], nil
  end

  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  local states = type(stack) == "table" and stack.states
  if type(states) ~= "table" then return nil end
  local bottom, top = states[1], states[#states]
  if type(bottom) ~= "table" or type(top) ~= "table" then return nil end
  if denied(top) then return nil end

  local kind = BOOT_SCREEN_IDS[bottom.screenId]
  if not kind then return nil end
  if top == bottom then return kind, top end
  -- Gen 1's title menu, CONTINUE info box and white flashes are plain
  -- states pushed over TitleState with no screenId; anything that has one
  -- (OPTION, a mod's title row) is a real screen and stays manual
  if bottom.screenId == "TitleState" and top.screenId == nil then
    return "menu", top
  end
  return nil
end

-- ------- SAVE from the START menu
-- Holding A after picking SAVE answers YES to "save the game?" (and Gen 2/3's
-- "overwrite?") and runs the saving text out.  Only while YES is the
-- highlighted answer: move the cursor to NO and turbo leaves it alone.

local gen1Theme = nil

local function gen1SaveBox()
  if gen1Theme == nil then
    local ok, res = pcall(require, "src.ui.Theme")
    gen1Theme = (ok and type(res) == "table") and res or false
  end
  return gen1Theme and gen1Theme.saveBox or nil
end

local GEN2_SAVE_PHASES = { confirm = true, overwrite = true }
local GEN3_SAVE_PHASES = { confirm = true, overwrite = true }

local function isSavePrompt(game)
  if isGen3(game) then
    local top = gen3StackTop(game)
    local Save = top and top.id == "save" and top.mod
    if type(Save) ~= "table" or not Save.open then return false end
    if Save._phase == "saved" then return true end
    return GEN3_SAVE_PHASES[Save._phase] == true and Save.cursor == 1
  end

  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  local states = type(stack) == "table" and stack.states
  if type(states) ~= "table" then return false end
  local top = states[#states]
  if type(top) ~= "table" then return false end

  -- Gen 2: src/ui/gen2/SaveMenu.lua, choice 1 = YES
  if top.screenId == "Gen2SaveMenu" then
    return GEN2_SAVE_PHASES[top.phase] == true and top.choice == 1
  end

  -- Gen 1: src/ui/StartMenu.lua's SAVE prompt is the only TextBox that pins
  -- its YES/NO at Theme.saveBox; the ChoiceBox it pushes sits right above
  local saveBox = gen1SaveBox()
  if not saveBox then return false end
  if top.isTextBox then return top.choiceBox == saveBox end
  local below = states[#states - 1]
  return type(below) == "table" and below.isTextBox == true
    and below.choiceBox == saveBox and top.index == 1
end

local function safeSaveTap(game, btn)
  if btn ~= "a" then return nil end
  local ok, res = pcall(isSavePrompt, game)
  return (ok and res == true) and "a" or nil
end

-- ------- POKEMON CENTER nurse (TURBO NURSE)
-- Holding A on the nurse answers HEAL / YES to "shall we heal your POKEMON?"
-- and the rest is plain text, so a held A runs to "We hope to see you
-- again!".  The nurse has no screen id of her own in any generation, so her
-- question is recognised by its text:
--   Gen 1: "Welcome to our POKEMON CENTER!" (+ "Shall we heal your POKEMON?")
--   Gen 2: "Shall we heal your #MON?"
--   Gen 3: "...welcome to the POKEMON CENTER... rest your POKEMON?"
-- Only while HEAL / YES is the highlighted answer.

local function flatText(t, out)
  out = out or {}
  if type(t) == "string" then
    out[#out + 1] = t
  elseif type(t) == "table" then
    for i = 1, #t do flatText(t[i], out) end
  end
  return out
end

local function isNurseText(text)
  if type(text) ~= "string" or text == "" then return false end
  local s = text:lower():gsub("[^a-z]", "")
  if s:find("healyour", 1, true) or s:find("restyour", 1, true) then
    return true
  end
  return s:find("welcome", 1, true) ~= nil and s:find("center", 1, true) ~= nil
end

local function textBoxIsNurse(tb)
  if type(tb) ~= "table" or not tb.isTextBox or not tb.choice then return false end
  if tb.defaultNo or tb.moneyWithChoice then return false end
  return isNurseText(table.concat(flatText(tb.pages), " "))
end

local function isNursePrompt(game)
  if isGen3(game) then
    if gen3StackTop(game) then return false end
    local Message = gen3Module(game, "src.ui.game3.message")
    if not Message or not callBool(Message, "isOpen") then return false end
    local ok, page = pcall(Message.currentPage)
    if not (ok and isNurseText(page)) then return false end
    local Choice = gen3Module(game, "src.ui.game3.choice")
    if Choice and (Choice.active or callBool(Choice, "isOpen")) then
      return Choice.cursor == 1
    end
    -- the question still typing out, before the YES/NO opens
    return true
  end

  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  local states = type(stack) == "table" and stack.states
  if type(states) ~= "table" then return false end
  local top = states[#states]
  if type(top) ~= "table" or denied(top) then return false end
  if top.isTextBox then return textBoxIsNurse(top) end
  -- the ChoiceBox the TextBox pushed over itself; index 1 = HEAL / YES
  return top.index == 1 and textBoxIsNurse(states[#states - 1])
end

local function safeNurseTap(game, btn)
  if btn ~= "a" then return nil end
  local ok, res = pcall(isNursePrompt, game)
  return (ok and res == true) and "a" or nil
end

-- ------- Battle menus (TURBO BATTLE, off by default)
-- Holding A also picks FIGHT on the command box and the highlighted move,
-- so a held A keeps attacking with the same move turn after turn.  Only on
-- FIGHT: with the cursor on BAG / POKEMON / RUN turbo leaves the box alone,
-- and Safari Zone menus (BALL first) and move reordering stay manual.
-- YES/NO prompts in battle (switch, next mon, learn move) are still manual.

local function isGen3BattleMenu(game)
  if gen3StackTop(game) then return false end
  local Choice = gen3Module(game, "src.ui.game3.choice")
  if Choice and (Choice.active or callBool(Choice, "isOpen")) then return false end
  local Battle = gen3Module(game, "src.core.game3.battle")
  if not callBool(Battle, "isActive") then return false end
  local Ui = gen3Module(game, "src.core.game3.battle.ui")
  if not Ui then return false end
  if callBool(Ui, "yesNoPending") or callBool(Ui, "choiceActive") then return false end
  local st = Ui._st
  if type(st) == "table" and (st.safari or st.oldManTutorial) then return false end
  -- pokefirered/src/battle_controller_player.c: action 1 = FIGHT
  if Ui._mode == "menu" then return Ui._menuIndex == 1 end
  if Ui._mode == "moves" then return Ui._swap == nil end
  -- double battles: confirm the default target
  return Ui._mode == "target"
end

local function isStackBattleMenu(game)
  local top = getStackTop(game)
  if not top or denied(top) then return false end
  if not (top.isBattle or top.isBattleState) then return false end
  if top.safari or top.demo then return false end
  if top.phase == "menu" then return top.menuIndex == 1 end
  -- Gen 1 "moveSelect", Gen 2 "moves"; a pending SELECT swap reads A as
  -- the swap target
  if top.phase == "moveSelect" or top.phase == "moves" then
    return top.moveSwapIndex == nil
  end
  -- Gen 2's "no PP / disabled" notes, which hand back to the menu
  return top.phase == "refuse-move" or top.phase == "refuse-menu"
end

local function isBattleMenu(game)
  if isGen3(game) then return isGen3BattleMenu(game) end
  return isStackBattleMenu(game)
end

local function safeBattleTap(game, btn)
  if btn ~= "a" then return nil end
  local ok, res = pcall(isBattleMenu, game)
  return (ok and res == true) and "a" or nil
end

-- Which button to tap for a held `btn` on the boot screens, or nil.
local function bootTap(game, btn)
  local kind, top = bootKind(game)
  if not kind then return nil end
  if kind == "menu" and btn == "b" then return nil end
  return "a", top
end

local function safeBootTap(game, btn)
  local ok, tapBtn, top = pcall(bootTap, game, btn)
  if ok then return tapBtn, top end
  return nil
end

local function isTextContext(game)
  if type(game) ~= "table" then return false end
  if isGen3(game) then return isGen3TextContext(game) end
  return isStackTextContext(game)
end

local function safeTextContext(game)
  local ok, res = pcall(isTextContext, game)
  return ok and res == true
end

local function isDown(input, btn)
  local ok, down = pcall(input.isDown, input, btn)
  return ok and down == true
end

return function(mod)
  mod.options:define({
    {
      key = "enabled",
      type = "toggle",
      label = "TURBO A/B",
      default = true,
    },
    {
      key = "turbo_a",
      type = "toggle",
      label = "TURBO A",
      default = true,
    },
    {
      key = "turbo_b",
      type = "toggle",
      label = "TURBO B",
      default = true,
    },
    {
      key = "turbo_boot",
      type = "toggle",
      label = "TURBO BOOT",
      default = true,
    },
    {
      key = "turbo_save",
      type = "toggle",
      label = "TURBO SAVE",
      default = true,
    },
    {
      key = "turbo_nurse",
      type = "toggle",
      label = "TURBO NURSE",
      default = true,
    },
    {
      key = "turbo_battle",
      type = "toggle",
      label = "TURBO BATTLE",
      default = false,
    },
    {
      key = "initial_delay",
      type = "number",
      label = "HOLD DELAY",
      default = DEFAULT_DELAY,
      min = 5,
      max = 60,
      step = 1,
    },
    {
      key = "repeat_speed",
      type = "choice",
      label = "REPEAT SPEED",
      default = DEFAULT_SPEED,
      choices = {
        { "1", 1 },
        { "2", 2 },
        { "3", 3 },
        { "4", 4 },
        { "5", 5 },
      },
    },
  })

  refreshOptions(mod)

  mod.exports.isTextContext = safeTextContext
  mod.exports.isBootContext = function(game)
    return safeBootTap(game, "a") ~= nil
  end
  mod.exports.isSaveContext = function(game)
    return safeSaveTap(game, "a") ~= nil
  end
  mod.exports.isNurseContext = function(game)
    return safeNurseTap(game, "a") ~= nil
  end
  mod.exports.isBattleMenuContext = function(game)
    return safeBattleTap(game, "a") ~= nil
  end
  mod.exports.denyScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = true end
  end
  mod.exports.allowScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = nil end
  end
  mod.exports.defaults = {
    initialDelay = DEFAULT_DELAY,
    repeatSpeed = DEFAULT_SPEED,
    repeatRate = DEFAULT_RATE,
    speedFrames = SPEED_FRAMES,
  }

  -- source-safe tap (#807); older engines fall back to the raw press queue
  local function tap(game, btn)
    if mod.input and type(mod.input.tap) == "function" then
      if pcall(mod.input.tap, mod.input, game, btn) then return end
    end
    local queue = game.input.pressQueue
    if type(queue) == "table" then queue[#queue + 1] = btn end
  end

  local holdBtn = nil
  local holdFrames = 0
  local holdDelay = DEFAULT_DELAY
  local holdRate = DEFAULT_RATE

  local function resetHold()
    holdBtn, holdFrames = nil, 0
    holdDelay, holdRate = cachedDelay, cachedRate
  end

  local function heldButton(input)
    local a = cachedTurboA and isDown(input, "a")
    local b = cachedTurboB and isDown(input, "b")
    if a and b then return "ab" end
    if a then return "a" end
    if b then return "b" end
    return nil
  end

  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    -- Fast Exit 1: Master toggle disabled
    if not cachedEnabled then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    local input = type(game) == "table" and game.input
    if type(input) ~= "table" or type(input.isDown) ~= "function" then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    -- Fast Exit 2: No A/B held (skips stack lookups entirely)
    local btn = heldButton(input)
    if not btn then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    -- A+B+SELECT+START is the soft reset combo; leave it untouched
    if isDown(input, "start") or isDown(input, "select") then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    local tapBtn, bootTop = nil, nil
    if cachedBoot then tapBtn, bootTop = safeBootTap(game, btn) end
    if not tapBtn and cachedSave then tapBtn = safeSaveTap(game, btn) end
    if not tapBtn and cachedNurse then tapBtn = safeNurseTap(game, btn) end
    if not tapBtn and cachedBattle then tapBtn = safeBattleTap(game, btn) end
    if not tapBtn and safeTextContext(game) then tapBtn = btn end
    if not tapBtn then
      if holdBtn then resetHold() end
      return nextFn(game, dt)
    end

    if btn ~= holdBtn then
      holdBtn = btn
      holdFrames = 0
      holdDelay = cachedDelay
      holdRate = cachedRate
    end

    holdFrames = holdFrames + 1
    local afterDelay = holdFrames - holdDelay
    if holdFrames > 1 and afterDelay >= 0 and afterDelay % holdRate == 0 then
      if bootTop and bootTop.screenId == "IntroMovie" then
        -- Gen 1's fight scene polls isDown for its own A edge
        -- (IntroMovie:pollInterrupt), which a physical hold never re-arms;
        -- forget the last poll so this tap reads as a fresh press
        bootTop.lastPollHeld = nil
      end
      if tapBtn == "ab" then
        tap(game, "a")
        tap(game, "b")
      else
        tap(game, tapBtn)
      end
    end

    return nextFn(game, dt)
  end)

  mod.events:on("mod.options_changed", function(ev)
    if not ev or ev.mod ~= mod.id then return end
    refreshOptions(mod)
  end)

  mod.events:on("game.ready", function()
    resetGen3Cache()
    resetHold()
  end)

  mod.events:on("save.loaded", function()
    refreshOptions(mod)
  end)

  mod.log:info("hold A/B on text to auto-advance (cached delay=%d rate=%d)",
    cachedDelay, cachedRate)
end
