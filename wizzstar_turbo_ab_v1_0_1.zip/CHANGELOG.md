# Changelog

Format: [keep a changelog](https://keepachangelog.com/en/1.1.0/).
Version headings match `manifest.json`'s `version`.

## 1.0.1

### Added

- **TURBO BOOT** option (default ON): hold **A** from launch to skip the copyright splash, intro movie and title screen and go straight into **CONTINUE**. With no save it picks **NEW GAME** and keeps going until the first real choice (gender, name).
- Holding **B** skips the boot movies only and stops on the title screen (B on a menu means "back").
- Gen 1: intro movie, Yellow intro, title, main menu and the CONTINUE info box. Gen 2: copyright, GAME FREAK / Crystal splash, Gold/Silver/Crystal intro, title and main menu. Gen 3: copyright, intro, title and main menu.
- **TURBO SAVE** option (default ON): keep holding **A** after picking **SAVE** in the START menu and it answers **YES** to "save the game?" (and "overwrite?" in Gen 2 / Gen 3), then runs the saving text out until the game is saved. Only while **YES** is highlighted: move the cursor to NO and turbo leaves it alone. B never answers save prompts.
- **TURBO NURSE** option (default ON, all gens): hold **A** on the POKéMON CENTER nurse and it answers **HEAL / YES** to "shall we heal your POKéMON?" and runs the text out until your POKéMON are healed and you can walk away. Only while HEAL / YES is highlighted; B never answers it.
- **TURBO BATTLE** option (default **OFF**, all gens): holding **A** also picks **FIGHT** on the battle command box and the highlighted move, so a held A keeps attacking with the same move every turn. Only while the cursor is on FIGHT — BAG / POKéMON / RUN, the Safari Zone menu and move reordering stay manual, and so do battle YES/NO prompts (switch, next Pokémon, learn a move).
- `exports.isBootContext(game)`, `exports.isSaveContext(game)`, `exports.isNurseContext(game)` and `exports.isBattleMenuContext(game)`.

### Unchanged

- OPTION, Mystery Gift, the clear-save / reset-clock combos and save-error messages on the boot screens stay manual.
- Every other YES/NO prompt (and a failed save's error message) still stops turbo.

## 1.0.0

### Added

- Hold **A** or **B** on dialogue and battle text to auto-advance after a short delay.
- **TURBO A/B**, **TURBO A**, **TURBO B**, **HOLD DELAY**, and **REPEAT SPEED** mod options (same delay and 1–5 speed ladder as G123R Turbo_Scroll Mod).
- Gen 1 / Gen 2: `TextBox` screens and battle text phases. Gen 3: field messages and battle text.
- YES/NO, multichoice, menus, battle command box and move select are never repeated.
- Presses go through `mod.input:tap` (source-safe), with a `pressQueue` fallback.
- Opt-out via `noTurboAB` / `turboAB = false`, screen-id denylist, and `mod.exports`.
